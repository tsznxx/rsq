/*****************************************************************************
  wRNA.h
  Last-modified: 20 Oct 2013 12:58:59 AM

  (c) 2012 - Yunfei Wang
  Center for Systems Biology
  Department of Molecular & Cell Biology
  University of Texas at Dallas
  tszn1984@gmail.com

  Licensed under the GNU General Public License 2.0 license.
******************************************************************************/

#ifndef WRNA_H
#define WRNA_H

#define GPP_COMPILE












#endif //WRNA_H

