#include "common.h"
CPPEXTERN float **get_ribosum(char *Alseq[], int n_seq, int length);
