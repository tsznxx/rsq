#include "common.h"
#ifndef MEA_H
#define MEA_H

CPPEXTERN float MEA(plist *p, char *structure, double gamma);

#endif
