#include "common.h"
#ifndef LFOLD_H
#define LFOLD_H

CPPEXTERN float  Lfold(char *string, char *structure, int maxdist);

#endif
