/*****************************************************************************
  test.cpp
  Last-modified: 09 Oct 2014 03:29:22 PM

  (c) 2012 - Yunfei Wang
  Center for Systems Biology
  Department of Molecular & Cell Biology
  University of Texas at Dallas
  yfwnag0405@gmail.com

  Licensed under the GNU General Public License 2.0 license.
******************************************************************************/

#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[])
{
	char *tst=NULL;
	cout << strlen(tst) << endl;
    return 0;
}

