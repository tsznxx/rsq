
//A pass through to get to tgamma
double gammafunction(double arg);