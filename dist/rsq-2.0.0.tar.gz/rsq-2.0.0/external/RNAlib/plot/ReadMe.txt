
This is the source code for RNAstructure, which includes tools for
RNA secondary structure prediction and analysis.

It is provided to you under the GNU GPL, which is spelled out
in gpl.txt.

----

The package help is provided in the manual directory as html files.
It can also be found online at:
http://rna.urmc.rochester.edu/RNAstructureHelp.html

----

Please contact David Mathews with any question or comments:
David_Mathews@urmc.rochester.edu
