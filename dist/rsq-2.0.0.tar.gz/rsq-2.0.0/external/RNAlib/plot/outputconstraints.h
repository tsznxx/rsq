
#if !defined(outputconstraintsh) 
#define outputconstraintsh

#include "structure.h"






void outputconstraints(const char *filename, structure *ct);
bool readconstraints(const char *filename, structure *ct);








#endif
